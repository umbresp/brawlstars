# BrawlStars

## Introduction
This is a python sync/async wrapper for the brawl stars API. Docs coming soon!

## Installation
`pip install brawlstars`
